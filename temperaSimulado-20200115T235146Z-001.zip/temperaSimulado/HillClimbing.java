package temperaSimulado;
import java.util.Scanner;

public class HillClimbing {
	
	private Problema problem;
//	private Node node;
	
	public HillClimbing() {
		problem = new Problema();
	}
	
	public int[] pertubacao(int[] estado, int iteracao) {
		
		int i = 0;
		int NovoEstado[] = new int[estado.length];
		problem.copiar(NovoEstado, estado); //faz copia do estado inicial em NovoEstado
		
		int vizinho[] = new int[estado.length];
		problem.copiar(vizinho, estado);
		
		while(i < iteracao) {
			if(meta(NovoEstado)) { //se ataques for zero
				problem.printar(NovoEstado);
				System.out.print(" ");
				System.out.println(problem.heuristica(NovoEstado));
				
				return NovoEstado;
			}
			else {
				
				vizinho = problem.sucessora(vizinho);
				
				if(problem.heuristica(vizinho) < problem.heuristica(NovoEstado)) {
					problem.copiar(NovoEstado, vizinho);
					//System.out.println(c.heuristica(x));
					//problem.printar
					//break;
				}
			}
			i++;
		}//fim do loop
		
		return NovoEstado;
	}//fim do metodo pertubacao
	
	public boolean meta(int[] estado) {
		int meta = problem.heuristica(estado);
		
		if(meta == 0) {
			return true;
		}
		return false;
	}

}//fim da classe