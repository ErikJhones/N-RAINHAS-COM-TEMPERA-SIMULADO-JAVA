package temperaSimulado;

public class Node {
	private int[] state;

    public Node(int[] state){
        this.state = state;
    }

//    Setar ou pegar os valores de cada variável.
    public int[] getState() {
        return state;
    }

    public void setState(int[] state) {
        this.state = state;
    }

}
