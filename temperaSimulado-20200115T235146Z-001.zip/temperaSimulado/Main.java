package temperaSimulado;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Busca search = new Busca(8, 1, (float) 0.99);
	}
}